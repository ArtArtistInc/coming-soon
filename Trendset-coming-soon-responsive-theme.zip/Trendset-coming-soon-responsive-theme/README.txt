Responsive Mobile First Web Template
------------------------------------
Author URI: http://webthemez.com/
Description: Vento is a responsive coming soon template, It is lightweight template comes with static background image and overlay pattern.


Features :
--------
=> Easy to use, Heigh quality coded HTML5 and CSS3.
=> Multi device compatibility
=> Responsive design with bootstrap
=> premium quality template

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com
=> For more free web themes: http://webthemez.com

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

**Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: webthemez.com).
